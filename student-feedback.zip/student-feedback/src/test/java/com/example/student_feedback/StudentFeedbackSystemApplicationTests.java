package com.example.student_feedback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentFeedbackSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
