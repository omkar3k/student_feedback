package com.example.student_feedback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentFeedbackSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentFeedbackSystemApplication.class, args);
	}

}
